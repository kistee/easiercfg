from easiercfg.easiercfg import Config
